package com.example.economica;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DataEntry extends Activity {
	
	EditText id1, id2, id4;
	EditText blnc1, blnc2, amnt1;
	EditText rt1, rt2, rt4;
	TextView report1;
	Button calc, bh, be;
	double intrest1, intrest2, loan1, net, nettmp, save;
	double  numbal2, numamnt;
	double numbal1;
	double numrt1, numrt2, numrt4;
	String sid1, sid2, sid4, sbal2, samnt, sbal1, srt1, srt2, srt4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dataentry);
        
        id1 = (EditText) findViewById(R.id.text_id1);
        id2 = (EditText) findViewById(R.id.text_id2);
        id4 = (EditText) findViewById(R.id.text_id4);
        blnc1 = (EditText) findViewById(R.id.text_blnce1);
        blnc2 = (EditText) findViewById(R.id.text_blnce2);
        amnt1 = (EditText) findViewById(R.id.text_loan1);
        rt1 = (EditText) findViewById(R.id.rate1);
        rt2 = (EditText) findViewById(R.id.rate2);
        rt4 = (EditText) findViewById(R.id.rate4);
        report1 = (TextView) findViewById(R.id.repo1);
        calc = (Button) findViewById(R.id.b101);
        bh = (Button) findViewById(R.id.b20);
        be = (Button) findViewById(R.id.b21);
        
        
        calc.setOnClickListener(new View.OnClickListener(){
       	     	
		
			public void onClick(View arg0) {
				
				sid1 = id1.getText().toString();
				sid2 = id2.getText().toString();
				sid4 = id4.getText().toString();
				
				sbal1 = blnc1.getText().toString();
				sbal2 = blnc2.getText().toString();	
				samnt = amnt1.getText().toString();
				srt1 = rt1.getText().toString();
				srt2 = rt2.getText().toString();
				srt4 = rt4.getText().toString();
				
				if( sid1.length() == 0 || sid2.length() == 0 || sid4.length() == 0 || sbal1.length() == 0 || sbal2.length() == 0 || samnt.length() == 0 || srt1.length() == 0 || srt2.length() == 0 || srt4.length() == 0)
				{
					report1.setText("Kindly enter all the details");
				}
		        
				else
				{
		        numbal1 = Double.parseDouble(sbal1);		        
		        numbal2 = Double.parseDouble(sbal2);        
		        numamnt = Double.parseDouble(samnt);
		        numrt1 = Double.parseDouble(srt1);
		        numrt2 = Double.parseDouble(srt2);
		        numrt4 = Double.parseDouble(srt4);
		        
		        if(numrt1 <= 100 && numrt2 <= 100 && numrt4 <= 100)
		        {
		        
		        intrest1 = ((numrt1 * numbal1)/ (100 * 12));
		        intrest2 = ((numrt2 * numbal2)/(100 * 12));
		        loan1 = ((numrt4 * numamnt)/(100 * 12));
		        
		        nettmp = intrest1 + intrest2;
		        net = loan1 - nettmp;
		        
		        if(net < 0)
		        	report1.setText("Congrats! Transactions in profit! \n Profit= " + (-net));
		        else
		        {
		        	if(numrt1 > numrt2)
		        	{
		        		save = ((net * 100 * 12) / numrt1);
		        		report1.setText("Invest Rs. "+ save + " in acoount no "+ sid1);
		        	}
		        	else
		        	{
		        		save = ((net * 100 * 12) / numrt2);
		        		report1.setText("Invest Rs. "+ save + " in acoount no "+ sid2);
		        	}
		        }
		        }
		        else{
		        	report1.setText("Invalid Rate value, should not be greater than 100");
		        }
				}
				
				
			}
        	
        });     
        
        bh.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent openPlayActivity = new Intent("com.example.economica.MAINACTIVITY");
				startActivity(openPlayActivity);
				
			}
        	
        });
        
        be.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				try{
					onBackPressed();
				}catch(Exception e){
					
				}
				
				
			}
        	
        });
        
    }

    
    public void onBackPressed(){
    	Intent intent = new Intent(Intent.ACTION_MAIN);
    	intent.addCategory(Intent.CATEGORY_HOME);
    	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    	this.finish();
    	startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
