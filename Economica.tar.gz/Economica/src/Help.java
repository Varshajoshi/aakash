import com.example.economica.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Help extends Activity {
	Button back;
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);
        back = (Button) findViewById(R.id.back1);
        
        back.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent openPlayActivity = new Intent("com.example.economica.MAINACTIVITY");
				startActivity(openPlayActivity);
				
			}
        	
        });
	}

}
